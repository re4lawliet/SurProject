<?php

namespace SUR;

use Illuminate\Database\Eloquent\Model;

class cliente extends Model
{
    //
}
