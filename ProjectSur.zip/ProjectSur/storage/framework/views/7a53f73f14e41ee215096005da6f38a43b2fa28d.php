<?php $__env->startSection('content'); ?>

    <div class="col-sm-offset-3 col-sm-6">
        <div class="panel-title">
            <h1>Modificar Proveedor</h1>
        </div>
    
        <div class="panel-body">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(url('proveedor')); ?>/<?php echo e($proveedor->id); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                <div class="form-group">
                    <label for="nombre_proveedor" class="control-label">Nombre del Proveedor</label>
                    <input type="text" name="nombre_proveedor" class="form-control" value="<?php echo e($proveedor->nombre_proveedor); ?>">
                </div>  

                <div class="form-group">
                    <label for="direccion_oficina" class="control-label">Direccion del Proveedor</label>
                    <input type="text" name="direccion_oficina" class="form-control" value="<?php echo e($proveedor->direccion_oficina); ?>">
                </div>
                
                 <div class="form-group">
                    <label for="nit_proveedor" class="control-label">Nit del Proveedor</label>
                    <input type="text" name="nit_proveedor" class="form-control" value="<?php echo e($proveedor->nit_proveedor); ?>">
                </div>

                 <div class="form-group">
                    <label for="telefono_proveedor" class="control-label">Telefono del Proveedor</label>
                    <input type="text" name="telefono_proveedor" class="form-control" value="<?php echo e($proveedor->telefono_proveedor); ?>">
                </div>

                 <div class="form-group">
                    <label for="correo_proveedor" class="control-label">Correo del Proveedor</label>
                    <input type="text" name="correo_proveedor" class="form-control" value="<?php echo e($proveedor->correo_proveedor); ?>">
                </div>

                <div class="form-group">
                    <label for="nombre_banco" class="control-label">Nombre del Banco</label>
                    <input type="text" name="nombre_banco" class="form-control" value="<?php echo e($proveedor->nombre_banco); ?>">
                </div>

                <div class="form-group row">
                    <label for="forma_pago" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Forma de Pago')); ?></label>

                    <div class="col-md-6">
                        <select id="forma_pago" type="text" class="form-control<?php echo e($errors->has('forma_pago') ? ' is-invalid' : ''); ?>" name="forma_pago" >
                            <option value="cheque" >Cheque</option>
                            <option value="deposito" >Deposito</option>
                            <option value="transferencia" >Transferencia</option>
                            <option value="otra" >Otra</option>
                        </select>
                        <?php if($errors->has('forma_pago')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('forma_pago')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group">
                    
                    <button type="submit" class="btn btn-default">
                        <i class="fa fa-plus"></i> Modificar Proveedor
                    </button>    
                    
                </div> 
            </form>   
            
        </div>
    </div>
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>