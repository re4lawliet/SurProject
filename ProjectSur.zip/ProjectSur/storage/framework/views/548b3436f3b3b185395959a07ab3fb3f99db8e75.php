<?php $__env->startSection('content'); ?>

    <div class="col-sm-offset-3 col-sm-6">
        <div class="panel-title">
            <h1>Modificar Proyecto</h1>
        </div>
    
        <div class="panel-body">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(url('proyecto')); ?>/<?php echo e($proyecto->id); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                <div class="form-group">
                    <label for="nombre_proyecto" class="control-label">Nombre del Proyecto</label>
                    <input type="text" name="nombre_proyecto" class="form-control" value="<?php echo e($proyecto->nombre_proyecto); ?>">
                </div>  

                <div class="form-group">
                    <label for="zona_proyecto" class="control-label">Zona del Proyecto</label>
                    <input type="text" name="zona_proyecto" class="form-control" value="<?php echo e($proyecto->zona_proyecto); ?>">
                </div>
                
                <div class="form-group row">
                    <label for="estado_proyecto" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Estado del Proyecto')); ?></label>
    
                    <div class="col-md-6">
                        <select id="estado_proyecto" type="text" class="form-control<?php echo e($errors->has('estado_proyecto') ? ' is-invalid' : ''); ?>" name="estado_proyecto" >
                            <option value="Proyecto Terminado" >Proyecto Terminado</option>
                            <option value="Proyecto en Construccion" >Proyecto en Construccion</option>
                            <option value="Proyecto en Planificacion" >Proyecto en Planificacion</option>
                            <option value="Oficina" >Oficina</option>
                        </select>
                        <?php if($errors->has('estado_proyecto')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('estado_proyecto')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>


                 <div class="form-group">
                    <label for="factura_a" class="control-label">Factura a:</label>
                    <input type="text" name="factura_a" class="form-control" value="<?php echo e($proyecto->factura_a); ?>">
                </div>

                 <div class="form-group">
                    <label for="factura_numero" class="control-label">Numero de Factura:</label>
                    <input type="text" name="factura_numero" class="form-control" value="<?php echo e($proyecto->factura_numero); ?>">
                </div>


                <div class="form-group">
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fa fa-plus"></i> Modificar Proyecto
                    </button>    
                    
                </div> 
            </form>   
            
        </div>
    </div>
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>