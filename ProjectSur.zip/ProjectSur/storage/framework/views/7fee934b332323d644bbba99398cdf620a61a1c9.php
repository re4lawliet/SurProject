<?php $__env->startSection('content'); ?>

    <!-- Inicio del Contenido de Pagina -->
    <center>
    <div class="panel-title">
        <h1><center>Administrador de Empresas</center></h1>
    </div>

    <!-- Formulario de Registro de Empresa -->    
  
    <div class="col-sm-offset-3 col-sm-6">
        <div class="panel-title">
                <h3><center>Registrar Empresa:</center></h3>
        </div>
    <div class="panel-body">

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(url('empresa')); ?>" method="POST">

            <?php echo e(csrf_field()); ?>


            <div class="form-group">
                <label for="nombre_empresa" class="control-label">Nombre de la Empresa</label>
                <input type="text" name="nombre_empresa" class="form-control">
            </div>  

            <div class="form-group">
                <label for="nit_empresa" class="control-label">NIT de la Empresa</label>
                <input type="text" name="nit_empresa" class="form-control">
            </div>
            
             <div class="form-group">
                <label for="direccion_empresa" class="control-label">Direccion de la Empresa</label>
                <input type="text" name="direccion_empresa" class="form-control">
            </div>

             <div class="form-group">
                <label for="telefono_oficina" class="control-label">Telefono de la Oficina</label>
                <input type="text" name="telefono_oficina" class="form-control">
            </div>

             <div class="form-group">
                <label for="telefono_empresa" class="control-label">Telefono de la Empresa</label>
                <input type="text" name="telefono_empresa" class="form-control">
            </div>

            <div class="form-group">
                <label for="correo_empresa" class="control-label">Correo de la Empresa</label>
                <input type="text" name="correo_empresa" class="form-control">
            </div>

            <div class="form-group">
                <label for="telefono_encargado" class="control-label">Telefono del Encargado</label>
                <input type="text" name="telefono_encargado" class="form-control">
            </div>

            <div class="form-group">
                <label for="correo_encargado" class="control-label">Correo del Encargado</label>
                <input type="text" name="correo_encargado" class="form-control">
            </div>

            <div class="form-group">
                <label for="nombre_encargado" class="control-label">Nombre del Encargado</label>
                <input type="text" name="nombre_encargado" class="form-control">
            </div>

            <div class="form-group">
                <label for="puesto_encargado" class="control-label">Puesto del Encargado</label>
                <input type="text" name="puesto_encargado" class="form-control">
            </div>

            <div class="form-group">
                <label for="nombre_banco" class="control-label">Nombre del Banco</label>
                <input type="text" name="nombre_banco" class="form-control">
            </div>

            <div class="form-group row">
                <label for="forma_pago" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Forma de Pago')); ?></label>

                <div class="col-md-6">
                    <select id="forma_pago" type="text" class="form-control<?php echo e($errors->has('forma_pago') ? ' is-invalid' : ''); ?>" name="forma_pago" >
                        <option value="cheque" >Cheque</option>
                        <option value="deposito" >Deposito</option>
                        <option value="transferencia" >Transferencia</option>
                        <option value="otra" >Otra</option>
                    </select>
                    <?php if($errors->has('forma_pago')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('forma_pago')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fa fa-plus"></i> Registrar Empresa  
                </button>    
                
            </div> 

            
        </form>   
        
    </div>
</div>

<br><br><br> 

<div class="container">

        <div class="col-12"><h2>Buscar Empresa
            
                <?php echo e(Form::open(['route' => 'empresas', 'method' => 'GET', 'class' => 'navbar-form navbar-left'])); ?>

                <div class="form-group">
                    <?php echo e(Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Nombre de Empresa'])); ?>

                </div>
                <div class="form-group">
                        <button type="submit" class="btn btn-primary">Buscar</button>
                </div>
                <?php echo e(Form::close()); ?>

        
        
        
        </h2></div>
</div>

<br>

    <!-- Tabla de Administrador -->


    <div class="col-md-12">
            <?php if(count($empresas) > 0): ?>
            <div class="panel panel-default">
                
                <div class="panel-heading">
                        <h2>Listado De Empresas</h2>
                </div>
                <div class="panel-body">
                    <table class="table table-striped task-table">
                        <thead>
                            <th>Nombre Empresa</th>
                            <th>Nit Empresa</th>
                            <th>Direccion Empresa</th>
                            <th>Telefono Oficina</th>
                            <th>Telefono Empresa</th>
                            <th>Correo Empresa</th>
                            <th>Telefono Encargado</th>
                            <th>Correo Encargado</th>
                            <th>Nombre Encargado</th>
                            <th>Puesto Encargado</th>
                            <th>Nombre Banco</th>
                            <th>Forma Pago</th>
                            <th>Modificar</th>
                            <th>Borrar</th>
                            <th>&nbsp;</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="table-text"><div><?php echo e($emps->nombre_empresa); ?></div></td>
                                    <td class="table-text"><div><?php echo e($emps->nit_empresa); ?></div></td>
                                    <td class="table-text"><div><?php echo e($emps->direccion_empresa); ?></div></td>
                                    <td class="table-text"><div><?php echo e($emps->telefono_oficina); ?></div></td>
                                    <td class="table-text"><div><?php echo e($emps->telefono_empresa); ?></div></td>
                                    <td class="table-text"><div><?php echo e($emps->correo_empresa); ?></div></td>
                                    <td class="table-text"><div><?php echo e($emps->telefono_encargado); ?></div></td>
                                    <td class="table-text"><div><?php echo e($emps->correo_encargado); ?></div></td>
                                    <td class="table-text"><div><?php echo e($emps->nombre_encargado); ?></div></td>
                                    <td class="table-text"><div><?php echo e($emps->puesto_encargado); ?></div></td>
                                    <td class="table-text"><div><?php echo e($emps->nombre_banco); ?></div></td>
                                    <td class="table-text"><div><?php echo e($emps->forma_pago); ?></div></td>
                                    

                                    <!-- Task Delete Button -->
                                    <td>
                                        <button type="submit" class="btn btn-success" onclick="location.href='empresas/<?php echo e($emps->id); ?>'">
                                            <i class="fa fa-btn fa-pencil"></i>Modificar
                                        </button>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(url('empresa')); ?>/<?php echo e($emps->id); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

    
                                            <button type="submit" class="btn btn-danger">
                                                <i class="fa fa-btn fa-trash"></i>Borrar
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($empresas->render()); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
    
    
</center>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>