<?php $__env->startSection('content'); ?>

    <div class="col-sm-offset-3 col-sm-6">
        <div class="panel-title">
            <h1>Modificar Empresa</h1>
        </div>
    
        <div class="panel-body">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(url('empresa')); ?>/<?php echo e($empresa->id); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                <div class="form-group">
                    <label for="nombre_empresa" class="control-label">Nombre de la Empresa</label>
                    <input type="text" name="nombre_empresa" class="form-control" value="<?php echo e($empresa->nombre_empresa); ?>">
                </div>  

                <div class="form-group">
                    <label for="nit_empresa" class="control-label">Nit de la Empresa</label>
                    <input type="text" name="nit_empresa" class="form-control" value="<?php echo e($empresa->nit_empresa); ?>">
                </div>
                
                 <div class="form-group">
                    <label for="direccion_empresa" class="control-label">Direccion de la Empresa</label>
                    <input type="text" name="direccion_empresa" class="form-control" value="<?php echo e($empresa->direccion_empresa); ?>">
                </div>

                 <div class="form-group">
                    <label for="telefono_oficina" class="control-label">Telefono de la Oficina</label>
                    <input type="text" name="telefono_oficina" class="form-control" value="<?php echo e($empresa->telefono_oficina); ?>">
                </div>

                 <div class="form-group">
                    <label for="telefono_empresa" class="control-label">Telefono de la Empresa</label>
                    <input type="text" name="telefono_empresa" class="form-control" value="<?php echo e($empresa->telefono_empresa); ?>">
                </div>

                <div class="form-group">
                    <label for="correo_empresa" class="control-label">Correo de la Empresa</label>
                    <input type="text" name="correo_empresa" class="form-control" value="<?php echo e($empresa->correo_empresa); ?>">
                </div>

                <div class="form-group">
                    <label for="telefono_encargado" class="control-label">Telefono del Encargado</label>
                    <input type="text" name="telefono_encargado" class="form-control" value="<?php echo e($empresa->telefono_encargado); ?>">
                </div>

                <div class="form-group">
                    <label for="correo_encargado" class="control-label">Correo del Encargado</label>
                    <input type="text" name="correo_encargado" class="form-control" value="<?php echo e($empresa->correo_encargado); ?>">
                </div>

                <div class="form-group">
                    <label for="nombre_encargado" class="control-label">Nombre del Encargado</label>
                    <input type="text" name="nombre_encargado" class="form-control" value="<?php echo e($empresa->nombre_encargado); ?>">
                </div>

                <div class="form-group">
                    <label for="puesto_encargado" class="control-label">Puesto del Encargado</label>
                    <input type="text" name="puesto_encargado" class="form-control" value="<?php echo e($empresa->puesto_encargado); ?>">
                </div>

                <div class="form-group">
                    <label for="nombre_banco" class="control-label">Nombre del Banco</label>
                    <input type="text" name="nombre_banco" class="form-control" value="<?php echo e($empresa->nombre_banco); ?>">
                </div>

                <div class="form-group row">
                    <label for="forma_pago" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Forma de Pago')); ?></label>

                    <div class="col-md-6">
                        <select id="forma_pago" type="text" class="form-control<?php echo e($errors->has('forma_pago') ? ' is-invalid' : ''); ?>" name="forma_pago" >
                            <option value="cheque" >Cheque</option>
                            <option value="deposito" >Deposito</option>
                            <option value="transferencia" >Transferencia</option>
                            <option value="otra" >Otra</option>
                        </select>
                        <?php if($errors->has('forma_pago')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('forma_pago')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group">
                    
                    <button type="submit" class="btn btn-default">
                        <i class="fa fa-plus"></i> Modificar Empresa
                    </button>    
                    
                </div> 
            </form>   
            
        </div>
    </div>
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>